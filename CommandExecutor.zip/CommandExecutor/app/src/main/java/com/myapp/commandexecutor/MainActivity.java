package com.myapp.commandexecutor;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static class AppInfo {
        final String displayName;
        final String[] keywords;
        final String packageName;

        AppInfo(String displayName, String[] keywords, String packageName) {
            this.displayName = displayName;
            this.keywords = keywords;
            this.packageName = packageName;
        }
    }

    private final AppInfo[] APPS = {
        new AppInfo("الموسيقى",    new String[]{"موسيقى","موسيقا","music","اغنية"},       "com.google.android.apps.youtube.music"),
        new AppInfo("جيميناي",     new String[]{"جيميناي","gemini","bard"},                "com.google.android.apps.bard"),
        new AppInfo("كلود",        new String[]{"كلود","claude"},                          "com.anthropic.claude"),
        new AppInfo("متجر بلاي",   new String[]{"متجر","بلاي","play","store"},               "com.android.vending"),
        new AppInfo("المصحف",      new String[]{"مصحف","قرآن","quran"},                    "com.quran.labs.androidquran"),
        new AppInfo("دولينجو",     new String[]{"دولينجو","duolingo","لغة"},                "com.duolingo"),
        new AppInfo("الحاسبة",     new String[]{"حاسبة","حاسبه","calculator","احسب"},       "com.google.android.calculator"),
        new AppInfo("الترجمة",     new String[]{"ترجمة","ترجم","translate"},                "com.google.android.apps.translate"),
        new AppInfo("لوكال سيند",  new String[]{"لوكال","سيند","localsend","أرسل"},         "org.localsend.localsend_app"),
        new AppInfo("يوتيوب",      new String[]{"يوتيوب","youtube","فيديو"},               "com.google.android.youtube"),
    };

    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;

    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean isTtsSpeaking = false;
    private boolean isListening = false;
    private TextView statusText;
    private TextView logText;

    private boolean voiceModeActive = false;
    private Runnable ttsCompleteCallback = null;
    private Button micButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("🚀 مركز التحكم الصوتي");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        main.addView(title);

        statusText = new TextView(this);
        statusText.setText("🔴 اضغط على الميكروفون للبدء");
        statusText.setTextSize(16);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, 0, 0, 16);
        main.addView(statusText);

        micButton = new Button(this);
        micButton.setText("🎙️ اضغط وتحدث");
        micButton.setTextSize(18);
        micButton.setMinHeight(150);
        micButton.setOnClickListener(v -> {
            if (voiceModeActive) stopVoiceMode();
            else startVoiceMode();
        });
        main.addView(micButton);

        addButton(main, "📌 ثبت في الإشعارات", v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(new Intent(this, VoiceService.class));
            } else {
                startService(new Intent(this, VoiceService.class));
            }
            toast("✅ تم التثبيت. اضغط على الإشعار للتحدث");
        });

        logText = new TextView(this);
        logText.setText("\n📋 سجل الأوامر:\n");
        logText.setTextSize(12);
        logText.setPadding(0, 24, 0, 0);
        main.addView(logText);

        addSectionTitle(main, "⚡ أوامر يدوية");
        addButton(main, "🔦 المصباح", v -> toggleFlash());
        addButton(main, "📷 الكاميرا", v -> openCamera());
        addButton(main, "📞 الاتصال", v -> {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:")));
            voiceModeActive = false;
        });
        addButton(main, "🌐 المتصفح", v -> {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com")));
            voiceModeActive = false;
        });
        addButton(main, "🗺️ الخريطة", v -> {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=here")));
            voiceModeActive = false;
        });
        addButton(main, "📺 يوتيوب", v -> openApp(APPS[9].packageName));

        addSectionTitle(main, "📱 التطبيقات");
        for (AppInfo app : APPS) {
            addAppRow(main, app.displayName, app.packageName);
        }

        scroll.addView(main);
        setContentView(scroll);

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (cameraManager != null) {
                String[] ids = cameraManager.getCameraIdList();
                if (ids != null && ids.length > 0) cameraId = ids[0];
            }
        } catch (Exception e) { cameraId = null; }

        tts = new TextToSpeech(this, this);

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            setupRecognitionListener();
        } else {
            toast("❌ التعرف على الصوت غير متوفر");
        }

        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> permissions = new ArrayList<>();
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(android.Manifest.permission.RECORD_AUDIO);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    permissions.add(android.Manifest.permission.POST_NOTIFICATIONS);
                }
            }
            if (!permissions.isEmpty()) {
                requestPermissions(permissions.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("START_VOICE", false) && ttsReady) {
            startVoiceMode();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    toast("⚠️ بعض الأذونات تم رفضها قد تؤثر على عمل التطبيق");
                    return;
                }
            }
            toast("✅ تم منح جميع الأذونات المطلوبة");
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true;
            int result = tts.setLanguage(new Locale("ar", "SA"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US);
            }
            tts.setSpeechRate(0.9f);

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { isTtsSpeaking = true; }

                @Override public void onDone(String utteranceId) {
                    isTtsSpeaking = false;
                    final Runnable callback = ttsCompleteCallback;
                    ttsCompleteCallback = null;
                    if (callback != null && !isFinishing() && !isDestroyed()) {
                        runOnUiThread(callback);
                    }
                }

                @Override public void onError(String utteranceId) {
                    isTtsSpeaking = false;
                    ttsCompleteCallback = null;
                }
            });

            if (getIntent().getBooleanExtra("START_VOICE", false)) {
                startVoiceMode();
            }
        }
    }

    private void startVoiceMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("❌ يرجى منح إذن الميكروفون أولاً");
            checkAndRequestPermissions();
            return;
        }

        voiceModeActive = true;
        if (micButton != null) micButton.setText("⏹️ إيقاف الوضع الصوتي");
        updateStatus("🟢 الوضع الصوتي نشط... استمع جيداً");
        speak("أنا جاهز. ما هو أمرك؟", this::startListening);
    }

    private void stopVoiceMode() {
        voiceModeActive = false;
        if (micButton != null) micButton.setText("🎙️ اضغط وتحدث");
        isListening = false;
        if (speechRecognizer != null) speechRecognizer.stopListening();
        updateStatus("🔴 الوضع الصوتي متوقف");
    }

    private void speak(String text, Runnable onComplete) {
        if (tts == null || !ttsReady) {
            if (onComplete != null) onComplete.run();
            return;
        }

        if (isTtsSpeaking) {
            mainHandler.postDelayed(() -> speak(text, onComplete), 300);
            return;
        }

        isTtsSpeaking = true;
        ttsCompleteCallback = onComplete;
        updateStatus("🔊 أتحدث: " + text);

        String utteranceId = "UTT_" + System.currentTimeMillis();
        int result;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Bundle params = new Bundle();
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId);
            result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        } else {
            HashMap<String, String> params = new HashMap<>();
            params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId);
            result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params);
        }

        if (result == TextToSpeech.ERROR) {
            isTtsSpeaking = false;
            ttsCompleteCallback = null;
            if (onComplete != null) onComplete.run();
        }
    }

    private void startListening() {
        if (!voiceModeActive || isTtsSpeaking) return;
        if (isListening) return;
        if (speechRecognizer == null) return;
        if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;

        isListening = true;
        updateStatus("👂 أستمع...");

        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            isListening = false;
            updateStatus("❌ تعذر بدء الاستماع");
        }
    }

    private void setupRecognitionListener() {
        if (speechRecognizer == null) return;
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { updateStatus("👂 استمع الآن..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}

            @Override public void onEndOfSpeech() {
                isListening = false;
                updateStatus("⏳ أعالج ما قلته...");
            }

            @Override public void onError(int error) {
                isListening = false;
                String msg;
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH: msg = "لم أفهم، كرر من فضلك"; break;
                    case SpeechRecognizer.ERROR_NETWORK: msg = "مشكلة في الشبكة"; break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: msg = "لا يوجد إذن ميكروفون"; break;
                    default: msg = "خطأ في الاستماع";
                }
                if (voiceModeActive && !isFinishing()) speak(msg, MainActivity.this::startListening);
            }

            @Override public void onResults(Bundle results) {
                isListening = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String command = matches.get(0);
                    logCommand(command);
                    processVoiceCommand(command);
                } else if (voiceModeActive && !isFinishing()) {
                    speak("لم أفهم، كرر من فضلك", MainActivity.this::startListening);
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void processVoiceCommand(String command) {
        String cmd = command.toLowerCase();
        String response = null;
        Runnable action = null;

        if (containsAny(cmd, "شغل","افتح","on") && containsAny(cmd, "مصباح","ضوء","light")) {
            response = "حاضر، شغّلت المصباح";
            action = this::turnFlashOn;
        }
        else if (containsAny(cmd, "طفئ","أطفئ","off") && containsAny(cmd, "مصباح","ضوء","light")) {
            response = "حاضر، طفيت المصباح";
            action = this::turnFlashOff;
        }
        else if (containsAny(cmd, "ارفع","اعلى","louder","up","volume up")) {
            response = "رفعت الصوت";
            action = this::raiseVolume;
        }
        else if (containsAny(cmd, "خفض","اقل","lower","down","volume down")) {
            response = "خفضت الصوت";
            action = this::lowerVolume;
        }
        else if (containsAny(cmd, "سطوع","brightness","اضاءة") && containsAny(cmd, "ارفع","اعلى","up","زود")) {
            response = "رفعت السطوع";
            action = this::raiseBrightness;
        }
        else if (containsAny(cmd, "سطوع","brightness","اضاءة") && containsAny(cmd, "خفض","اقل","down","قلل")) {
            response = "خفضت السطوع";
            action = this::lowerBrightness;
        }
        else if (containsAny(cmd, "كاميرا","camera","صورة")) {
            response = "أفتح الكاميرا الآن";
            action = this::openCamera;
        }
        else if (containsAny(cmd, "اتصل","اتصال","phone","call")) {
            response = "أفتح شاشة الاتصال";
            action = () -> {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:")));
                voiceModeActive = false;
            };
        }
        else if (containsAny(cmd, "انترنت","متصفح","google","بحث")) {
            response = "أفتح المتصفح";
            action = () -> {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com")));
                voiceModeActive = false;
            };
        }
        else if (containsAny(cmd, "خريطة","خريطه","map","موقع")) {
            response = "أفتح الخريطة";
            action = () -> {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=here")));
                voiceModeActive = false;
            };
        }
        else {
            for (AppInfo app : APPS) {
                for (String keyword : app.keywords) {
                    if (cmd.contains(keyword)) {
                        if (containsAny(cmd, "أغلق","اغلق","close","kill")) {
                            response = "أغلق " + app.displayName;
                            final String pkg = app.packageName;
                            action = () -> closeApp(pkg);
                        } else if (containsAny(cmd, "خروج","وقف","exit","stop")) {
                            response = "أوقف " + app.displayName;
                            final String pkg = app.packageName;
                            action = () -> exitApp(pkg);
                        } else {
                            response = "أفتح " + app.displayName;
                            final String pkg = app.packageName;
                            action = () -> openApp(pkg);
                        }
                        break;
                    }
                }
                if (response != null) break;
            }
        }

        if (response == null) {
            if (containsAny(cmd, "سلام","أهلا","مرحبا","hello")) {
                response = "وعليكم السلام! أنا مساعدك الصوتي. ماذا تريد أن تفعل؟";
            }
            else if (containsAny(cmd, "شكرا","thanks")) {
                response = "العفو! هل تحتاج شيئاً آخر؟";
            }
            else if (containsAny(cmd, "مع السلامة","bye","باي")) {
                response = "مع السلامة! أتمنى لك يوماً سعيداً";
                voiceModeActive = false;
            }
            else {
                response = "لم أفهم الأمر. جرّب: افتح يوتيوب، شغل المصباح، ارفع الصوت";
            }
        }

        final Runnable finalAction = action;
        final boolean wasVoiceModeActive = voiceModeActive;

        speak(response, () -> {
            if (!voiceModeActive && micButton != null && !isFinishing()) {
                micButton.setText("🎙️ اضغط وتحدث");
            }
            if (finalAction != null) {
                finalAction.run();
            }
            if (wasVoiceModeActive && voiceModeActive) {
                startListening();
            }
        });
    }

    private boolean containsAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw)) return true;
        }
        return false;
    }

    private void turnFlashOn() {
        if (cameraManager == null || cameraId == null) {
            toast("⚠️ الكاميرا غير متوفرة");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, true);
                isFlashOn = true;
            }
        } catch (CameraAccessException e) {
            toast("⚠️ الكاميرا مشغولة حالياً");
        } catch (Exception e) {
            toast("⚠️ خطأ: " + e.getMessage());
        }
    }

    private void turnFlashOff() {
        if (cameraManager == null || cameraId == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, false);
                isFlashOn = false;
            }
        } catch (Exception e) {
            toast("⚠️ خطأ: " + e.getMessage());
        }
    }

    private void raiseVolume() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audio != null) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            }
        } catch (Exception e) { toast("⚠️ خطأ في التحكم بالصوت"); }
    }

    private void lowerVolume() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audio != null) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            }
        } catch (Exception e) { toast("⚠️ خطأ في التحكم بالصوت"); }
    }

    private void raiseBrightness() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                toast("⚠️ يرجى منح الإذن لتعديل إعدادات النظام ثم أعد المحاولة");
                return;
            }
        }
        try {
            int current = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            int newVal = Math.min(255, current + 51);
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, newVal);

            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = newVal / 255.0f;
            getWindow().setAttributes(lp);
        } catch (Exception e) { toast("⚠️ خطأ في تعديل السطوع"); }
    }

    private void lowerBrightness() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                toast("⚠️ يرجى منح الإذن لتعديل إعدادات النظام ثم أعد المحاولة");
                return;
            }
        }
        try {
            int current = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            int newVal = Math.max(0, current - 51);
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, newVal);

            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = newVal / 255.0f;
            getWindow().setAttributes(lp);
        } catch (Exception e) { toast("⚠️ خطأ في تعديل السطوع"); }
    }

    private void openCamera() {
        try {
            startActivity(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
            voiceModeActive = false;
        } catch (Exception e) { toast("❌ الكاميرا غير متوفرة"); }
    }

    private void openApp(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                startActivity(i);
                voiceModeActive = false;
            } else {
                toast("❌ التطبيق غير مثبت");
            }
        } catch (Exception e) { toast("❌ خطأ في الفتح"); }
    }

    private void closeApp(String pkg) {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) am.killBackgroundProcesses(pkg);
            toast("🔒 تم إرسال طلب إغلاق الخلفية");
        } catch (Exception e) { toast("❌ خطأ في الإغلاق"); }
    }

    private void exitApp(String pkg) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + pkg));
            startActivity(intent);
            voiceModeActive = false;
        } catch (Exception e) { toast("❌ تعذر فتح الإعدادات"); }
    }

    private void toggleFlash() {
        if (isFlashOn) turnFlashOff(); else turnFlashOn();
        toast(isFlashOn ? "💡 شغّلت" : "🌑 طفيت");
    }

    private void updateStatus(String text) { if (statusText != null) statusText.setText(text); }
    private void logCommand(String cmd) { if (logText != null) logText.append("> " + cmd + "\n"); }

    private void addSectionTitle(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setPadding(0, 16, 0, 8);
        parent.addView(tv);
    }

    private void addButton(LinearLayout parent, String text, android.view.View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(13);
        btn.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 4, 0, 4);
        btn.setLayoutParams(p);
        btn.setOnClickListener(listener);
        parent.addView(btn);
    }

    private void addAppRow(LinearLayout parent, String name, String pkg) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 4, 0, 4);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(13);
        label.setPadding(8, 0, 8, 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f);
        label.setLayoutParams(lp);
        row.addView(label);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        Button b1 = new Button(this); b1.setText("فتح"); b1.setTextSize(11); b1.setLayoutParams(bp);
        b1.setOnClickListener(v -> openApp(pkg)); row.addView(b1);

        Button b2 = new Button(this); b2.setText("إغلاق"); b2.setTextSize(11); b2.setLayoutParams(bp);
        b2.setOnClickListener(v -> closeApp(pkg)); row.addView(b2);

        Button b3 = new Button(this); b3.setText("خروج"); b3.setTextSize(11); b3.setLayoutParams(bp);
        b3.setOnClickListener(v -> exitApp(pkg)); row.addView(b3);

        parent.addView(row);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        voiceModeActive = false;
        mainHandler.removeCallbacksAndMessages(null);

        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
    }
}
